#A partir del programa anterior, modifica el código para que sea el usuario quién introduzca el número de veces que desea que repita la frase Buenos días. Con While.

cont=int(input("¿Cuantas veces quieres repetir el programa? -> "))

var1=0
while var1!=cont:
    print("buenos dias")
    var1+=1