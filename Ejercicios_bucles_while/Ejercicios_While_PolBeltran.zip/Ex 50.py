#Realiza un programa que de los buenos días 3 veces. Con While 

var1=0

while var1!=3:
    print("buenos dias")
    var1+=1