# Imprime el siguiente patrón utilizando for

var1="54321"

for cont in range(0, len(var1)):
    print(var1)
    var1=var1[1:]
