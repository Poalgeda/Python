#Programa que al introducir un número por teclado permita mostrar ese número de veces tu nombre.
veces=int(input("¿Cuantas veces deseas repetir el mensaje?: "))
for contador in range(0, veces):
    print("Pol Beltran Castellà")
    